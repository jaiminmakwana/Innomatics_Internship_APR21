import numpy as np

lst = list(map(int, input().split()))

print(np.zeros(lst, int))
print(np.ones(lst, int))
