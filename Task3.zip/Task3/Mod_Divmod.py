
a = int(input())
b = int(input())

div = a // b
rem = a % b

print(div)
print(rem)
print(divmod(a, b))
