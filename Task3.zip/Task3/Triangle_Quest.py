
for i in range((int(input()))-1):
    print(int((10 ** (i+1) - 1) / 9) * (i+1))

    # for j in range(i+1):
    #     print(i+1, end='')
    # print()