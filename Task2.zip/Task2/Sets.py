
import array as arr

lst = [1,2,2,34,3434]

s = set(lst)

print(sum(s))